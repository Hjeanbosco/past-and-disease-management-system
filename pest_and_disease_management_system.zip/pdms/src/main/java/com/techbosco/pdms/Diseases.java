/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.techbosco.pdms;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 *
 * @author Adiministrator
 */
@Entity
@Table(name = "diseases")
@NamedQueries({
    @NamedQuery(name = "Diseases.findAll", query = "SELECT d FROM Diseases d"),
    @NamedQuery(name = "Diseases.findByDisId", query = "SELECT d FROM Diseases d WHERE d.disId = :disId"),
    @NamedQuery(name = "Diseases.findByName", query = "SELECT d FROM Diseases d WHERE d.name = :name"),
    @NamedQuery(name = "Diseases.findByCreatedAt", query = "SELECT d FROM Diseases d WHERE d.createdAt = :createdAt"),
    @NamedQuery(name = "Diseases.findByCouses", query = "SELECT d FROM Diseases d WHERE d.couses = :couses"),
    @NamedQuery(name = "Diseases.findBySymptoms", query = "SELECT d FROM Diseases d WHERE d.symptoms = :symptoms"),
    @NamedQuery(name = "Diseases.findByPhoto", query = "SELECT d FROM Diseases d WHERE d.photo = :photo"),
    @NamedQuery(name = "Diseases.findBySolution", query = "SELECT d FROM Diseases d WHERE d.solution = :solution")})
public class Diseases implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "dis_id")
    private Integer disId;
    @Size(max = 30)
    @Column(name = "name")
    private String name;
    @Column(name = "created_at")
    @Temporal(TemporalType.DATE)
    private Date createdAt;
    @Size(max = 30)
    @Column(name = "couses")
    private String couses;
    @Size(max = 200)
    @Column(name = "symptoms")
    private String symptoms;
    @Size(max = 255)
    @Column(name = "photo")
    private String photo;
    @Size(max = 255)
    @Column(name = "solution")
    private String solution;

    public Diseases() {
    }

    public Diseases(Integer disId) {
        this.disId = disId;
    }

    public Integer getDisId() {
        return disId;
    }

    public void setDisId(Integer disId) {
        this.disId = disId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCouses() {
        return couses;
    }

    public void setCouses(String couses) {
        this.couses = couses;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (disId != null ? disId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Diseases)) {
            return false;
        }
        Diseases other = (Diseases) object;
        if ((this.disId == null && other.disId != null) || (this.disId != null && !this.disId.equals(other.disId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.techbosco.pdms.Diseases[ disId=" + disId + " ]";
    }
    
}
