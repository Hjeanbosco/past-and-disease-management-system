/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.techbosco.pdms;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.transaction.UserTransaction;
import com.techbosco.pdms.util.JsfUtil;
import com.techbosco.pdms.util.PagingInfo;
import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

/**
 *
 * @author Adiministrator
 */
public class DiseasesController {

    public DiseasesController() {
        pagingInfo = new PagingInfo();
        converter = new DiseasesConverter();
    }
    private Diseases diseases = null;
    private List<Diseases> diseasesItems = null;
    private DiseasesFacade jpaController = null;
    private DiseasesConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "my_persistence_unit")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public DiseasesFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (DiseasesFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "diseasesJpa");
        }
        return jpaController;
    }

    public SelectItem[] getDiseasesItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getDiseasesItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Diseases getDiseases() {
        if (diseases == null) {
            diseases = (Diseases) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentDiseases", converter, null);
        }
        if (diseases == null) {
            diseases = new Diseases();
        }
        return diseases;
    }

    public String listSetup() {
        reset(true);
        return "diseases_list";
    }

    public String createSetup() {
        reset(false);
        diseases = new Diseases();
        return "diseases_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(diseases);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Diseases was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("diseases_detail");
    }

    public String editSetup() {
        return scalarSetup("diseases_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        diseases = (Diseases) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentDiseases", converter, null);
        if (diseases == null) {
            String requestDiseasesString = JsfUtil.getRequestParameter("jsfcrud.currentDiseases");
            JsfUtil.addErrorMessage("The diseases with id " + requestDiseasesString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String diseasesString = converter.getAsString(FacesContext.getCurrentInstance(), null, diseases);
        String currentDiseasesString = JsfUtil.getRequestParameter("jsfcrud.currentDiseases");
        if (diseasesString == null || diseasesString.length() == 0 || !diseasesString.equals(currentDiseasesString)) {
            String outcome = editSetup();
            if ("diseases_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit diseases. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(diseases);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Diseases was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentDiseases");
        Integer id = new Integer(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Diseases was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
        if (relatedControllerOutcome != null) {
            return relatedControllerOutcome;
        }
        return listSetup();
    }

    public List<Diseases> getDiseasesItems() {
        if (diseasesItems == null) {
            getPagingInfo();
            diseasesItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return diseasesItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "diseases_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "diseases_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        diseases = null;
        diseasesItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Diseases newDiseases = new Diseases();
        String newDiseasesString = converter.getAsString(FacesContext.getCurrentInstance(), null, newDiseases);
        String diseasesString = converter.getAsString(FacesContext.getCurrentInstance(), null, diseases);
        if (!newDiseasesString.equals(diseasesString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
